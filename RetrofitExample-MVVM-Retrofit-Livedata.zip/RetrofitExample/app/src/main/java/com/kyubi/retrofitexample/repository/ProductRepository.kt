package com.kyubi.retrofitexample.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.kyubi.retrofitexample.helpers.UserHelper
import com.kyubi.retrofitexample.models.Products
import com.kyubi.retrofitexample.retrofit.RetrofitHelper

class ProductRepository(private val product_service: RetrofitHelper) {
    private val productLiveData = MutableLiveData<List<Products>>()
    val products: LiveData<List<Products>>
        get() = productLiveData

    suspend fun getProductList() {
        val result = product_service.getInstance().getProductList()
        if (result?.body() != null) {
            productLiveData.postValue(result.body())

        }
    }
}