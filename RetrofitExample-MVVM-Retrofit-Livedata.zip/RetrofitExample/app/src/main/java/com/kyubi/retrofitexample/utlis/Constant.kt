package com.kyubi.retrofitexample.utlis

object Constant {
    const val BASE_URL = "https://fakestoreapi.com/"
}